import streamlit as st
import cv2
import numpy as np
import tensorflow as tf
from utils.mediapipe_utils import extract_landmarks

st.set_page_config(page_title="Sign Language Translator", layout="centered")
st.title("🤟 Real-Time Sign Language Translator")

model = tf.keras.models.load_model("models/sign_model.h5")
labels = sorted(list(os.listdir("dataset/landmarks")))

run = st.checkbox("Start Camera")
FRAME_WINDOW = st.image([])

cap = cv2.VideoCapture(0)

while run:
    ret, frame = cap.read()
    if not ret:
        break

    landmarks = extract_landmarks(frame)
    if landmarks is not None:
        pred = model.predict(np.expand_dims(landmarks, axis=0))
        sign = labels[np.argmax(pred)]

        cv2.putText(frame, sign, (50, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 2, (0,255,0), 3)

    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    FRAME_WINDOW.image(frame)

cap.release()
