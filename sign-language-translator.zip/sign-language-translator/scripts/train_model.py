import numpy as np
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.utils import to_categorical

DATA_DIR = "dataset/landmarks"
labels = os.listdir(DATA_DIR)

X, y = [], []

for idx, label in enumerate(labels):
    for file in os.listdir(f"{DATA_DIR}/{label}"):
        X.append(np.load(f"{DATA_DIR}/{label}/{file}"))
        y.append(idx)

X = np.array(X)
y = to_categorical(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = Sequential([
    Dense(128, activation='relu', input_shape=(63,)),
    Dense(64, activation='relu'),
    Dense(len(labels), activation='softmax')
])

model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

model.fit(X_train, y_train, epochs=30, validation_data=(X_test, y_test))
model.save("models/sign_model.h5")
