import cv2
import os
import numpy as np
from utils.mediapipe_utils import extract_landmarks

INPUT_DIR = "dataset/raw_images/asl_alphabet_train/asl_alphabet_train"

OUTPUT_DIR = "dataset/landmarks"

os.makedirs(OUTPUT_DIR, exist_ok=True)

for label in os.listdir(INPUT_DIR):
    label_dir = os.path.join(INPUT_DIR, label)

    if not os.path.isdir(label_dir):
        continue

    save_dir = os.path.join(OUTPUT_DIR, label)
    os.makedirs(save_dir, exist_ok=True)

    print(f"Processing {label}...")

    count = 0
    for img_file in os.listdir(label_dir):
        img_path = os.path.join(label_dir, img_file)

        img = cv2.imread(img_path)
        if img is None:
            continue

        landmarks = extract_landmarks(img)
        if landmarks is not None:
            np.save(os.path.join(save_dir, f"{count}.npy"), landmarks)
            count += 1

    print(f"Saved {count} samples for {label}")
