import cv2
import numpy as np
import tensorflow as tf
from utils.mediapipe_utils import extract_landmarks
import os

model = tf.keras.models.load_model("models/sign_model.h5")
labels = os.listdir("dataset/landmarks")

cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    landmarks = extract_landmarks(frame)

    if landmarks is not None:
        prediction = model.predict(np.expand_dims(landmarks, axis=0))
        sign = labels[np.argmax(prediction)]
        cv2.putText(frame, sign, (50,100),
                    cv2.FONT_HERSHEY_SIMPLEX, 2, (0,255,255), 3)

    cv2.imshow("Sign Translator", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
