import cv2
import numpy as np
import os
from utils.mediapipe_utils import extract_landmarks

LABEL = "A"  # change sign label
SAVE_PATH = f"dataset/landmarks/{LABEL}"
os.makedirs(SAVE_PATH, exist_ok=True)

cap = cv2.VideoCapture(0)
count = 0

while cap.isOpened():
    ret, frame = cap.read()
    landmarks = extract_landmarks(frame)

    if landmarks is not None:
        np.save(f"{SAVE_PATH}/{count}.npy", landmarks)
        count += 1
        cv2.putText(frame, f"Saved: {count}", (10,40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

    cv2.imshow("Collecting Data", frame)
    if cv2.waitKey(1) == 27 or count >= 300:
        break

cap.release()
cv2.destroyAllWindows()
